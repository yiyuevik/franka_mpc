import glob
from utils.plotting import plot_trajectories
import os, sys
import numpy as np
import configs
from utils.helpers import compute_end_effector_position

REPO_ROOT = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(REPO_ROOT) == "scripts":
    REPO_ROOT = os.path.dirname(REPO_ROOT)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    data_path = os.path.join(project_root, "data/multimodality/parallel_rollout_20251023_1203/group_04")
    simX = np.load(os.path.join(data_path, "main_simX.npy"))
    simX = simX[7,:,:]
    simU = np.load(os.path.join(data_path, "main_simU.npy"))
    simU = simU[7,:,:]
    end_effector_positions = np.load(os.path.join(data_path, "main_pos.npy"))
    target_position = configs.target_position
    plot_trajectories(simX, simU, end_effector_positions, target_position)


    # branch_path = os.path.join(project_root, "data/multimodality/parallel_rollout_20251023_1203/group_04/branches_data/branch_step_007.npy")
    # if os.path.isfile(branch_path):
    #     try:
    #         branch_entries = np.load(branch_path, allow_pickle=True)
    #     except Exception as e:
    #         print(f"Failed to load branch file {branch_path}: {e}")
    #     # branch_entries is expected to be a list-like of dicts with keys 'x_traj' and 'u_traj'
    #     for j, entry in enumerate(branch_entries):
    #         try:
    #             X = np.array(entry["x_traj"])  # (H+1, nx)
    #             U = np.array(entry["u_traj"])  # (H, nu)
    #         except Exception:
    #             # Fallback: entry might be a numpy scalar containing a python object
    #             try:
    #                 entry = entry.item()
    #                 X = np.array(entry["x_traj"])  # (H+1, nx)
    #                 U = np.array(entry["u_traj"])  # (H, nu)
    #             except Exception as e:
    #                 print(f"Skipping malformed branch entry in {data_path}: {e}")
    #                 continue
    #         H = U.shape[0]
    #         X_trim = X[:H, :]
    #         pos_list = [compute_end_effector_position(q) for q in X_trim] 
    #         pos = np.asarray(pos_list)
    #         plot_trajectories(X_trim, U, pos, idx = j)

if __name__ == "__main__":
    main()