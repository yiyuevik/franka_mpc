import numpy as np
import sys
import os
import glob

# 添加项目路径到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.helpers import compute_end_effector_position
import configs
import matplotlib.pyplot as plt

def load_and_plot_trajectory(file, save_dir):
    """
    Load .npy file data and plot trajectories
    
    Args:
        file: Path to .npy file
        save_dir: Directory to save the plot
    """
    try:
        print(f"📁 Loading data file: {file}")
    
        data = np.load(file, allow_pickle=True)
        U_trajs = [np.asarray(item["x_traj"]) for item in data]
        print(f"✅ Data loaded successfully, containing {len(U_trajs)} trajectories")

        # Create plot
        plt.figure(figsize=(10, 6))
        for i, U in enumerate(U_trajs):
            T, nu = U.shape
            time = np.arange(T)
            for j in range(nu):
                plt.plot(U[:, j], label=f'Traj {i} - Joint {j+1}')
        
        plt.xlabel('Time step')
        plt.ylabel('Control Input')
        # Get the branch step number from filename for the title
        branch_num = os.path.basename(file).split('_')[2].split('.')[0]
        plt.title(f'Control Input Trajectories - Branch Step {branch_num}')
        plt.grid()
        
        # Save plot
        plot_filename = f'trajectory_u_branch_{branch_num}.png'
        plt.savefig(os.path.join(save_dir, plot_filename))
        plt.close()
        
        print(f"✅ Plot saved as {plot_filename}")
        
    except Exception as e:
        print(f"❌ Error processing file {file}: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Specify the directory path
    dir_path = "/app/output/parallel_rollout_20251010_102844/group_00/branches_data"
    
    if os.path.exists(dir_path):
        new_save_dir = os.path.join(os.path.dirname(dir_path), f"branch_plots")
        os.makedirs(new_save_dir, exist_ok=True)
        # Find all branch step files
        branch_files = glob.glob(os.path.join(dir_path, "branch_step_*.npy"))
        
        if branch_files:
            print(f"Found {len(branch_files)} branch step files")
            for file in sorted(branch_files):
                load_and_plot_trajectory(file, new_save_dir)
            print("✅ All trajectories have been plotted!")
        else:
            print(f"❌ No branch step files found in: {dir_path}")
    else:
        print(f"❌ Directory does not exist: {dir_path}")